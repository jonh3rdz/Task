function calcular_interes(n1, n2) {
    return n1 + n2;
}

let cantidad = sumar(10, 20);
let interes = sumar(50, 60);
let tiempo = sumar(100, 30);

console.log("El total uno es: " + resultadoUno);
console.log("El total dos es: " + resultadoDos);
console.log("El total tres es: " + resultadoTres);